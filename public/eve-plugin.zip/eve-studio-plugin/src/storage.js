/**
 * storage.js — local persistence for the E.V.E. plugin
 */

const KEY_AUTH         = 'eve_auth'
const KEY_ONBOARD      = 'eve_onboarded'
const KEY_WORKSPACE    = 'eve_workspace'
const KEY_PROJECTS     = 'eve_projects'
const KEY_LAST_FOLDERS = 'eve_last_folders'

function get(key) {
  try { return JSON.parse(localStorage.getItem(key)) } catch { return null }
}
function set(key, value) { localStorage.setItem(key, JSON.stringify(value)) }
function remove(key) { localStorage.removeItem(key) }

window.storage = {
  saveAuth:     (s) => set(KEY_AUTH, s),
  getAuth:      ()  => get(KEY_AUTH),
  clearAuth:    ()  => remove(KEY_AUTH),
  hasOnboarded: ()  => !!get(KEY_ONBOARD),
  markOnboarded:()  => set(KEY_ONBOARD, true),
  saveWorkspace:(p) => set(KEY_WORKSPACE, p),
  getWorkspace: ()  => get(KEY_WORKSPACE),
  saveProjectPath(clientId, path) {
    const p = get(KEY_PROJECTS) || {}
    p[clientId] = path
    set(KEY_PROJECTS, p)
  },
  getProjectPath(clientId) {
    return (get(KEY_PROJECTS) || {})[clientId] || null
  },
  saveLastFolder(clientId, path) {
    const f = get(KEY_LAST_FOLDERS) || {}
    f[clientId] = path
    set(KEY_LAST_FOLDERS, f)
  },
  getLastFolder(clientId) {
    return (get(KEY_LAST_FOLDERS) || {})[clientId] || null
  },
}
