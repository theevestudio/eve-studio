/**
 * storage.js — local persistence for the E.V.E. plugin
 */

const KEY_AUTH          = 'eve_auth'
const KEY_ONBOARD       = 'eve_onboarded'
const KEY_WORKSPACE     = 'eve_workspace'
const KEY_PROJECTS      = 'eve_projects'
const KEY_LAST_FOLDERS  = 'eve_last_folders'
const KEY_SEQ_SETTINGS  = 'eve_seq_settings'
const KEY_MANIFESTS     = 'eve_manifests'      // footage manifests per client
const KEY_PLUGIN_VER    = 'eve_plugin_version' // last seen server version

const DEFAULT_SEQ_SETTINGS = {
  resolution: '1080x1920',
  fps: '29.97',
  codec: 'H.264',
}

function get(key) {
  try { return JSON.parse(localStorage.getItem(key)) } catch { return null }
}
function set(key, value) { localStorage.setItem(key, JSON.stringify(value)) }
function remove(key) { localStorage.removeItem(key) }

window.storage = {
  // ── Auth ───────────────────────────────────────────────────────────
  saveAuth:     (s) => set(KEY_AUTH, s),
  getAuth:      ()  => get(KEY_AUTH),
  clearAuth:    ()  => remove(KEY_AUTH),

  // ── Onboarding ─────────────────────────────────────────────────────
  hasOnboarded: ()  => !!get(KEY_ONBOARD),
  markOnboarded:()  => set(KEY_ONBOARD, true),

  // ── Workspace ──────────────────────────────────────────────────────
  saveWorkspace:(p) => set(KEY_WORKSPACE, p),
  getWorkspace: ()  => get(KEY_WORKSPACE),

  // ── Per-client project paths ───────────────────────────────────────
  saveProjectPath(clientId, path) {
    const p = get(KEY_PROJECTS) || {}
    p[clientId] = path
    set(KEY_PROJECTS, p)
  },
  getProjectPath(clientId) {
    return (get(KEY_PROJECTS) || {})[clientId] || null
  },

  // ── Per-client last footage folder ────────────────────────────────
  saveLastFolder(clientId, path) {
    const f = get(KEY_LAST_FOLDERS) || {}
    f[clientId] = path
    set(KEY_LAST_FOLDERS, f)
  },
  getLastFolder(clientId) {
    return (get(KEY_LAST_FOLDERS) || {})[clientId] || null
  },

  // ── Sequence settings ─────────────────────────────────────────────
  saveSeqSettings(s) { set(KEY_SEQ_SETTINGS, s) },
  getSeqSettings()   { return get(KEY_SEQ_SETTINGS) || DEFAULT_SEQ_SETTINGS },

  // ── Footage manifests (Deep Scan results) ─────────────────────────
  saveManifest(clientId, manifest) {
    const all = get(KEY_MANIFESTS) || {}
    all[clientId] = manifest
    set(KEY_MANIFESTS, all)
  },
  getManifest(clientId) {
    return (get(KEY_MANIFESTS) || {})[clientId] || null
  },
  clearManifest(clientId) {
    const all = get(KEY_MANIFESTS) || {}
    delete all[clientId]
    set(KEY_MANIFESTS, all)
  },

  // ── Plugin version tracking ───────────────────────────────────────
  saveSeenVersion(v)  { set(KEY_PLUGIN_VER, v) },
  getSeenVersion()    { return get(KEY_PLUGIN_VER) },
}
