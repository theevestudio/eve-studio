/**
 * app.js — main controller for the E.V.E. Premiere Pro plugin
 * Depends on: window.storage, window.api, window.premiere (loaded via script tags)
 */

let state = {
  running: false,
  currentClient: null,
  currentProject: null,
  scripts: [],
  selectedScript: null,
  workspace: null,
}

// ─── Views ────────────────────────────────────────
function showView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'))
  const el = document.getElementById(`view-${id}`)
  if (el) el.classList.add('active')
}

// ─── Toast ────────────────────────────────────────
let toastTimer = null
function toast(message, type) {
  const el = document.getElementById('toast')
  if (!el) return
  el.textContent = message
  el.className = `toast ${type || ''} show`
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => el.classList.remove('show'), 3000)
}

// ─── Status ───────────────────────────────────────
function setStatus(type, message) {
  const pill = document.getElementById('status-pill')
  if (!pill) return
  pill.className = `status-pill ${type}`
  pill.querySelector('.status-label').textContent = message
}

function setRunning(running) {
  state.running = running
  const header = document.querySelector('.global-header img')
  if (header) {
    header.style.animation = running ? 'pulse-glow 1.4s ease-in-out infinite' : ''
  }
}

// ─── Init ─────────────────────────────────────────
async function init() {
  state.workspace = storage.getWorkspace()

  const saved = storage.getAuth()
  if (saved?.refresh_token) {
    try {
      const session = await api.refreshSession(saved.refresh_token)
      api.setSession(session)
      storage.saveAuth(session)

      const user = await api.getUser()
      const profile = await api.getProfile(user.id)

      if (!profile?.eve_subscription_active) {
        showView('subscription-gate')
        return
      }

      showView('main')
      await loadClients()
    } catch {
      storage.clearAuth()
      showView(storage.hasOnboarded() ? 'login' : 'onboarding')
    }
  } else {
    showView(storage.hasOnboarded() ? 'login' : 'onboarding')
  }
}

// ─── Onboarding ───────────────────────────────────
let onboardStep = 0
const ONBOARD_STEPS = ['welcome', 'storage', 'workflow', 'checklist']

function nextOnboardStep() {
  onboardStep = Math.min(onboardStep + 1, ONBOARD_STEPS.length - 1)
  renderOnboardStep()
}

function prevOnboardStep() {
  onboardStep = Math.max(onboardStep - 1, 0)
  renderOnboardStep()
}

function renderOnboardStep() {
  document.querySelectorAll('.onboarding-step').forEach(s => s.classList.remove('active'))
  document.querySelector(`[data-step="${ONBOARD_STEPS[onboardStep]}"]`).classList.add('active')
}

function finishOnboarding() {
  const items = document.querySelectorAll('.checklist-item input')
  const allChecked = Array.from(items).every(i => i.checked)
  if (!allChecked) { toast('Please confirm all items to continue', 'error'); return }
  storage.markOnboarded()
  showView('login')
}

function switchStorageTab(platform) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'))
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'))
  document.querySelector(`[data-tab="${platform}"]`).classList.add('active')
  document.querySelector(`[data-panel="${platform}"]`).classList.add('active')
}

// ─── Login ────────────────────────────────────────
async function handleLogin() {
  const email = document.getElementById('login-email').value.trim()
  const password = document.getElementById('login-password').value
  const errEl = document.getElementById('login-error')
  const btn = document.getElementById('login-btn')

  errEl.textContent = ''
  btn.disabled = true
  btn.textContent = 'Signing in...'

  try {
    const session = await api.signIn(email, password)
    api.setSession(session)
    storage.saveAuth(session)

    const user = await api.getUser()
    const profile = await api.getProfile(user.id)

    if (!profile?.eve_subscription_active) { showView('subscription-gate'); return }

    showView('main')
    await loadClients()
  } catch (err) {
    errEl.textContent = err.message || 'Login failed'
  } finally {
    btn.disabled = false
    btn.textContent = 'Sign in to E.V.E.'
  }
}

function handleSignOut() {
  storage.clearAuth()
  api.setSession(null)
  state.currentClient = null
  state.scripts = []
  state.selectedScript = null
  showView('login')
}

// ─── Clients ──────────────────────────────────────
async function loadClients() {
  const select = document.getElementById('client-select')
  select.innerHTML = '<option value="">— Select a client —</option>'
  try {
    const themes = await api.getThemes()
    themes.forEach(t => {
      const opt = document.createElement('option')
      opt.value = t.id
      opt.textContent = t.client_name
      opt.dataset.name = t.client_name
      select.appendChild(opt)
    })
    document.getElementById('workspace-banner').style.display = state.workspace ? 'none' : 'flex'
  } catch {
    toast('Failed to load clients', 'error')
  }
}

async function handleClientChange() {
  const select = document.getElementById('client-select')
  const clientId = select.value
  const clientName = select.options[select.selectedIndex]?.dataset?.name || ''

  state.currentClient = clientId ? { id: clientId, name: clientName } : null
  state.selectedScript = null
  document.getElementById('script-detail').classList.remove('visible')

  if (!clientId) {
    document.getElementById('script-list').innerHTML = ''
    document.getElementById('client-display-name').textContent = ''
    document.getElementById('client-display-name').classList.add('empty')
    setStatus('idle', 'No client selected')
    return
  }

  document.getElementById('client-display-name').textContent = clientName
  document.getElementById('client-display-name').classList.remove('empty')
  setStatus('running', 'Loading scripts...')
  setRunning(true)

  try {
    state.scripts = await api.getScriptsForTheme(clientId)
    renderScriptList()
    if (state.workspace) await openClientProject(clientId, clientName)
    setStatus('ready', 'Ready')
  } catch {
    toast('Failed to load scripts', 'error')
    setStatus('idle', 'Error loading')
  } finally {
    setRunning(false)
  }
}

function renderScriptList() {
  const list = document.getElementById('script-list')
  list.innerHTML = ''
  if (state.scripts.length === 0) {
    list.innerHTML = `<div class="empty-state">No scripts yet for this client.<br>Generate some in the EVE Studio dashboard.</div>`
    return
  }
  state.scripts.forEach(script => {
    const item = document.createElement('div')
    item.className = 'script-item'
    item.dataset.id = script.id
    const content = script.script_content || {}
    const virality = script.virality_score ? `<span class="virality">${script.virality_score}/10 virality</span>` : ''
    const importedTag = script.source === 'imported' ? `<span style="color:#fbbf24;font-size:10px;background:rgba(120,80,0,0.3);border:1px solid rgba(180,120,0,0.4);border-radius:4px;padding:1px 6px;">⚠ Imported</span>` : ''
    item.innerHTML = `
      <div class="script-title">${script.title || content.hook || 'Untitled'} ${importedTag}</div>
      <div class="script-meta">
        ${script.hook_type ? `<span>${script.hook_type}</span>` : ''}
        ${virality}
        ${content.duration_estimate ? `<span>${content.duration_estimate}</span>` : ''}
      </div>`
    item.addEventListener('click', () => selectScript(script))
    list.appendChild(item)
  })
}

function selectScript(script) {
  state.selectedScript = script
  document.querySelectorAll('.script-item').forEach(el => {
    el.classList.toggle('active', el.dataset.id === script.id)
  })
  const content = script.script_content || {}
  const detail = document.getElementById('script-detail')
  const importWarning = detail.querySelector('[data-imported-warning]')
  if (importWarning) importWarning.style.display = script.source === 'imported' ? 'block' : 'none'
  detail.querySelector('[data-field="hook"]').textContent = content.hook || '—'
  detail.querySelector('[data-field="body"]').innerHTML = (content.body || []).map(l => `<p>${l}</p>`).join('')
  detail.querySelector('[data-field="cta"]').textContent = content.cta || '—'
  const broll = detail.querySelector('[data-field="broll"]')
  if (content.b_roll_notes?.length) {
    broll.innerHTML = content.b_roll_notes.map(n => `<div class="broll-item">${n}</div>`).join('')
    broll.parentElement.style.display = 'block'
  } else {
    broll.parentElement.style.display = 'none'
  }
  detail.classList.add('visible')
}

// ─── Workspace ────────────────────────────────────
async function handleSetWorkspace() {
  setRunning(true)
  try {
    const path = await premiere.pickWorkspaceFolder()
    if (!path) return
    state.workspace = path
    storage.saveWorkspace(path)
    document.getElementById('workspace-banner').style.display = 'none'
    toast('Workspace set', 'success')
    if (state.currentClient) await openClientProject(state.currentClient.id, state.currentClient.name)
  } catch { toast('Could not set workspace', 'error') }
  finally { setRunning(false) }
}

async function openClientProject(clientId, clientName) {
  if (!state.workspace) return
  setStatus('running', 'Opening project...')
  setRunning(true)
  const projectPath = premiere.buildProjectPath(state.workspace, clientName)
  storage.saveProjectPath(clientId, projectPath)
  try {
    state.currentProject = await premiere.openOrCreateProject(projectPath, clientName)
    setStatus('ready', `${clientName} project open`)
    toast(`${clientName} project ready`, 'success')
  } catch {
    toast('Could not open Premiere project', 'error')
    setStatus('idle', 'Project error')
  } finally { setRunning(false) }
}

// ─── Actions ──────────────────────────────────────
async function handleCreateSequence() {
  if (!state.currentProject) { toast('No project open — select a client first', 'error'); return }
  if (!state.selectedScript) { toast('Select a script to create a sequence for', 'error'); return }

  const seqName = premiere.buildSequenceName(
    state.currentClient.name,
    state.selectedScript.title || state.selectedScript.script_content?.hook || 'Untitled'
  )
  setRunning(true)
  setStatus('running', 'Creating sequence...')
  try {
    const exists = await premiere.sequenceExists(state.currentProject, seqName)
    if (exists) { toast('Sequence already exists for this script', 'error'); return }
    await premiere.createSequence(state.currentProject, seqName)
    toast(`Sequence created: ${seqName}`, 'success')
    setStatus('ready', 'Sequence ready')
  } catch { toast('Failed to create sequence', 'error'); setStatus('idle', 'Error') }
  finally { setRunning(false) }
}

async function handleImportFootage() {
  if (!state.currentProject) { toast('No project open — select a client first', 'error'); return }
  const lastFolder = storage.getLastFolder(state.currentClient?.id)
  setRunning(true)
  setStatus('running', 'Selecting footage...')
  try {
    const { imported, folderPath } = await premiere.importFootage(state.currentProject, lastFolder)
    if (imported === 0) { setStatus('ready', 'Ready'); return }
    if (folderPath && state.currentClient) storage.saveLastFolder(state.currentClient.id, folderPath)
    toast(`${imported} file${imported !== 1 ? 's' : ''} imported`, 'success')
    setStatus('ready', 'Footage imported')
  } catch { toast('Import failed', 'error'); setStatus('idle', 'Error') }
  finally { setRunning(false) }
}

function showOnboardingGuide() {
  onboardStep = 0
  renderOnboardStep()
  showView('onboarding')
}

// ─── Expose to HTML onclick handlers ──────────────
window.app = {
  init, nextOnboardStep, prevOnboardStep, finishOnboarding,
  switchStorageTab, handleLogin, handleSignOut,
  handleClientChange, handleSetWorkspace,
  handleCreateSequence, handleImportFootage, showOnboardingGuide,
}

// Auto-start
init().catch(err => {
  document.body.innerHTML = `<div style="padding:20px;color:#f87171;font-family:monospace;font-size:11px;white-space:pre-wrap;">${err?.stack || err}</div>`
})
