/**
 * app.js — main controller for the E.V.E. Premiere Pro plugin
 * Depends on: window.storage, window.api, window.premiere,
 *             window.scanner, window.editor (loaded via script tags)
 */

let state = {
  running:         false,
  currentClient:   null,
  currentProject:  null,
  scripts:         [],
  selectedScript:  null,
  workspace:       null,
  manifest:        null,   // footage manifest from Deep Scan
  scanProgress:    null,   // { message, current, total }
  editProgress:    null,   // { message, step, steps }
}

// ─── Views ──────────────────────────────────────────
function showView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'))
  const el = document.getElementById(`view-${id}`)
  if (el) el.classList.add('active')
}

// ─── Toast ──────────────────────────────────────────
let toastTimer = null
function toast(message, type) {
  const el = document.getElementById('toast')
  if (!el) return
  el.textContent = message
  el.className = `toast ${type || ''} show`
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => el.classList.remove('show'), 3500)
}

// ─── Status ─────────────────────────────────────────
function setStatus(type, message) {
  const pill = document.getElementById('status-pill')
  if (!pill) return
  pill.className = `status-pill ${type}`
  pill.querySelector('.status-label').textContent = message
}

function setRunning(running) {
  state.running = running
  const header = document.querySelector('.global-header img')
  if (header) {
    header.style.animation = running ? 'pulse-glow 1.4s ease-in-out infinite' : ''
  }
}

// ─── Version Check ───────────────────────────────────
async function checkVersion() {
  try {
    const info = await api.checkVersion()
    if (!info?.version) return

    const local  = api.getCurrentVersion()
    const remote = info.version

    // Simple semver comparison: different = newer (server is always authoritative)
    if (local !== remote) {
      const banner = document.getElementById('update-banner')
      const label  = document.getElementById('update-version-label')
      if (banner) banner.style.display = 'flex'
      if (label)  label.textContent    = `v${remote} available`
      storage.saveSeenVersion(remote)
    }
  } catch { /* non-fatal */ }
}

// ─── Sequence Settings ───────────────────────────────
function initSeqSettings() {
  const s = storage.getSeqSettings()
  document.getElementById('seq-resolution').value = s.resolution
  document.getElementById('seq-fps').value         = s.fps
  document.getElementById('seq-codec').value       = s.codec
  document.getElementById('seq-settings-saved').style.display = 'inline'
}

function toggleSeqSettings() {
  const panel   = document.getElementById('seq-settings-panel')
  const chevron = document.getElementById('seq-settings-chevron')
  const open    = panel.style.display === 'none'
  panel.style.display   = open ? 'block' : 'none'
  chevron.textContent   = open ? '▲' : '▼'
  if (open) initSeqSettings()
}

function saveSeqSettings() {
  const s = {
    resolution: document.getElementById('seq-resolution').value,
    fps:        document.getElementById('seq-fps').value,
    codec:      document.getElementById('seq-codec').value,
  }
  storage.saveSeqSettings(s)
  document.getElementById('seq-settings-saved').style.display = 'inline'
  document.getElementById('seq-settings-panel').style.display = 'none'
  document.getElementById('seq-settings-chevron').textContent = '▼'
  toast(`Settings saved — ${s.resolution} · ${s.fps}fps · ${s.codec}`, 'success')
}

// ─── Init ────────────────────────────────────────────
async function init() {
  state.workspace = storage.getWorkspace()
  if (storage.getSeqSettings()) {
    document.getElementById('seq-settings-saved').style.display = 'inline'
  }

  const saved = storage.getAuth()
  if (saved?.refresh_token) {
    try {
      const session = await api.refreshSession(saved.refresh_token)
      api.setSession(session)
      storage.saveAuth(session)

      const user    = await api.getUser()
      const profile = await api.getProfile(user.id)

      if (!profile?.eve_subscription_active) {
        showView('subscription-gate')
        return
      }

      showView('main')
      await loadClients()
      checkVersion() // non-blocking
    } catch {
      storage.clearAuth()
      showView(storage.hasOnboarded() ? 'login' : 'onboarding')
    }
  } else {
    showView(storage.hasOnboarded() ? 'login' : 'onboarding')
  }
}

// ─── Onboarding ──────────────────────────────────────
let onboardStep = 0
const ONBOARD_STEPS = ['welcome', 'storage', 'workflow', 'checklist']

function nextOnboardStep() {
  onboardStep = Math.min(onboardStep + 1, ONBOARD_STEPS.length - 1)
  renderOnboardStep()
}

function prevOnboardStep() {
  onboardStep = Math.max(onboardStep - 1, 0)
  renderOnboardStep()
}

function renderOnboardStep() {
  document.querySelectorAll('.onboarding-step').forEach(s => s.classList.remove('active'))
  document.querySelector(`[data-step="${ONBOARD_STEPS[onboardStep]}"]`).classList.add('active')
}

function finishOnboarding() {
  const items      = document.querySelectorAll('.checklist-item input')
  const allChecked = Array.from(items).every(i => i.checked)
  if (!allChecked) { toast('Please confirm all items to continue', 'error'); return }
  storage.markOnboarded()
  showView('login')
}

function switchStorageTab(platform) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'))
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'))
  document.querySelector(`[data-tab="${platform}"]`).classList.add('active')
  document.querySelector(`[data-panel="${platform}"]`).classList.add('active')
}

// ─── Login ───────────────────────────────────────────
async function handleLogin() {
  const email    = document.getElementById('login-email').value.trim()
  const password = document.getElementById('login-password').value
  const errEl    = document.getElementById('login-error')
  const btn      = document.getElementById('login-btn')

  errEl.textContent = ''
  btn.disabled  = true
  btn.textContent = 'Signing in…'

  try {
    const session = await api.signIn(email, password)
    api.setSession(session)
    storage.saveAuth(session)

    const user    = await api.getUser()
    const profile = await api.getProfile(user.id)

    if (!profile?.eve_subscription_active) { showView('subscription-gate'); return }

    showView('main')
    await loadClients()
    checkVersion()
  } catch (err) {
    errEl.textContent = err.message || 'Login failed'
  } finally {
    btn.disabled    = false
    btn.textContent = 'Sign in to E.V.E.'
  }
}

function handleSignOut() {
  storage.clearAuth()
  api.setSession(null)
  state.currentClient  = null
  state.scripts        = []
  state.selectedScript = null
  state.manifest       = null
  showView('login')
}

// ─── Clients ─────────────────────────────────────────
async function loadClients() {
  const select = document.getElementById('client-select')
  select.innerHTML = '<option value="">— Select a client —</option>'
  try {
    const themes = await api.getThemes()
    themes.forEach(t => {
      const opt = document.createElement('option')
      opt.value       = t.id
      opt.textContent = t.client_name
      opt.dataset.name = t.client_name
      select.appendChild(opt)
    })
    document.getElementById('workspace-banner').style.display = state.workspace ? 'none' : 'flex'
  } catch {
    toast('Failed to load clients', 'error')
  }
}

async function handleClientChange() {
  const select     = document.getElementById('client-select')
  const clientId   = select.value
  const clientName = select.options[select.selectedIndex]?.dataset?.name || ''

  state.currentClient  = clientId ? { id: clientId, name: clientName } : null
  state.selectedScript = null
  state.manifest       = clientId ? storage.getManifest(clientId) : null
  document.getElementById('script-detail').classList.remove('visible')

  if (!clientId) {
    document.getElementById('script-list').innerHTML = ''
    document.getElementById('client-display-name').textContent = ''
    document.getElementById('client-display-name').classList.add('empty')
    setStatus('idle', 'No client selected')
    updateScanUI()
    return
  }

  document.getElementById('client-display-name').textContent = clientName
  document.getElementById('client-display-name').classList.remove('empty')
  setStatus('running', 'Loading scripts…')
  setRunning(true)

  try {
    state.scripts = await api.getScriptsForTheme(clientId)
    renderScriptList()
    if (state.workspace) await openClientProject(clientId, clientName)
    setStatus('ready', 'Ready')
  } catch {
    toast('Failed to load scripts', 'error')
    setStatus('idle', 'Error loading')
  } finally {
    setRunning(false)
    updateScanUI()
  }
}

function renderScriptList() {
  const list = document.getElementById('script-list')
  list.innerHTML = ''
  if (state.scripts.length === 0) {
    list.innerHTML = `<div class="empty-state">No scripts yet for this client.<br>Generate some in the EVE Studio dashboard.</div>`
    return
  }
  state.scripts.forEach(script => {
    const item = document.createElement('div')
    item.className   = 'script-item'
    item.dataset.id  = script.id
    const content    = script.script_content || {}
    const virality   = script.virality_score ? `<span class="virality">${script.virality_score}/10</span>` : ''
    const importedTag = script.source === 'imported'
      ? `<span style="color:#fbbf24;font-size:10px;background:rgba(120,80,0,0.3);border:1px solid rgba(180,120,0,0.4);border-radius:4px;padding:1px 6px;">⚠ Imported</span>` : ''
    const filmedTag  = script.filmed
      ? `<span style="color:#34d399;font-size:10px;background:rgba(0,80,40,0.35);border:1px solid rgba(52,211,153,0.35);border-radius:4px;padding:1px 6px;">🎬 Filmed</span>` : ''
    item.innerHTML = `
      <div class="script-title">${script.title || content.hook || 'Untitled'} ${filmedTag}${importedTag}</div>
      <div class="script-meta">
        ${script.hook_type ? `<span>${script.hook_type}</span>` : ''}
        ${virality}
        ${content.duration_estimate ? `<span>${content.duration_estimate}</span>` : ''}
      </div>`
    item.addEventListener('click',    () => selectScript(script))
    item.addEventListener('dblclick', () => openScriptFocus(script))
    list.appendChild(item)
  })
}

function selectScript(script) {
  state.selectedScript = script
  document.querySelectorAll('.script-item').forEach(el =>
    el.classList.toggle('active', el.dataset.id === script.id)
  )
  const content      = script.script_content || {}
  const detail       = document.getElementById('script-detail')
  const importWarn   = detail.querySelector('[data-imported-warning]')
  if (importWarn) importWarn.style.display = script.source === 'imported' ? 'block' : 'none'
  detail.querySelector('[data-field="hook"]').textContent  = content.hook || '—'
  detail.querySelector('[data-field="body"]').innerHTML    = (content.body || []).map(l => `<p>${l}</p>`).join('')
  detail.querySelector('[data-field="cta"]').textContent   = content.cta  || '—'
  const broll = detail.querySelector('[data-field="broll"]')
  if (content.b_roll_notes?.length) {
    broll.innerHTML = content.b_roll_notes.map(n => `<div class="broll-item">${n}</div>`).join('')
    broll.parentElement.style.display = 'block'
  } else {
    broll.parentElement.style.display = 'none'
  }
  detail.classList.add('visible')

  const btn = document.getElementById('filmed-btn')
  if (btn) {
    btn.textContent       = script.filmed ? '🎬 Filmed — tap to undo' : 'Mark as filmed'
    btn.style.color       = script.filmed ? '#34d399' : ''
    btn.style.borderColor = script.filmed ? 'rgba(52,211,153,0.4)' : ''
  }

  // Enable Run Edit button only if manifest exists
  updateEditButton()
}

// ─── Filmed toggle ───────────────────────────────────
async function handleToggleFilmed() {
  if (!state.selectedScript) return
  const next = !state.selectedScript.filmed
  try {
    await api.setFilmed(state.selectedScript.id, next)
    state.selectedScript.filmed = next
    state.scripts = state.scripts.map(s =>
      s.id === state.selectedScript.id ? { ...s, filmed: next } : s
    )
    renderScriptList()
    document.querySelectorAll('.script-item').forEach(el =>
      el.classList.toggle('active', el.dataset.id === state.selectedScript.id)
    )
    const btn = document.getElementById('filmed-btn')
    if (btn) {
      btn.textContent       = next ? '🎬 Filmed — tap to undo' : 'Mark as filmed'
      btn.style.color       = next ? '#34d399' : ''
      btn.style.borderColor = next ? 'rgba(52,211,153,0.4)' : ''
    }
    toast(next ? 'Marked as filmed' : 'Marked as not filmed', 'success')
  } catch {
    toast('Could not update filmed status', 'error')
  }
}

// ─── Script Focus View ────────────────────────────────
function openScriptFocus(script) {
  state.selectedScript = script
  const content = script.script_content || {}

  document.getElementById('focus-title').textContent  = script.title || content.hook || 'Untitled'
  document.getElementById('focus-client').textContent = state.currentClient?.name || ''

  const badge = document.getElementById('focus-filmed-badge')
  if (badge) badge.style.display = script.filmed ? 'inline-flex' : 'none'

  document.getElementById('focus-hook').textContent = content.hook || '—'

  const bodyEl = document.getElementById('focus-body')
  bodyEl.innerHTML = ''
  ;(content.body || []).forEach(line => {
    if (!line.trim()) return
    const el = document.createElement('p')
    el.className  = 'focus-body-line'
    el.textContent = line
    bodyEl.appendChild(el)
  })

  document.getElementById('focus-cta').textContent = content.cta || '—'

  const brollSection = document.getElementById('focus-broll-section')
  const brollEl      = document.getElementById('focus-broll')
  if (content.b_roll_notes?.length) {
    brollEl.innerHTML = content.b_roll_notes.map(n => `<div class="focus-broll-item">· ${n}</div>`).join('')
    brollSection.style.display = 'block'
  } else {
    brollSection.style.display = 'none'
  }

  // Run button label
  const runLabel = document.getElementById('focus-run-label')
  if (runLabel) runLabel.textContent = `Run E.V.E. Edit — "${script.title || 'this script'}"`

  // EVE Edit button state
  const editBtn = document.getElementById('focus-edit-btn')
  if (editBtn) {
    const hasManifest = !!state.manifest?.clips?.length
    editBtn.disabled = !hasManifest
    editBtn.title    = hasManifest ? '' : 'Run Deep Scan first to enable autonomous editing'
  }

  document.getElementById('view-main').style.display  = 'none'
  document.getElementById('view-focus').style.display = 'flex'
}

function closeScriptFocus() {
  document.getElementById('view-focus').style.display = 'none'
  document.getElementById('view-main').style.display  = 'block'
}

async function handleRunWithScript() {
  if (!state.selectedScript) return
  closeScriptFocus()
  await handleCreateSequence()
}

// ─── Deep Scan ────────────────────────────────────────
function updateScanUI() {
  const block   = document.getElementById('scan-block')
  const status  = document.getElementById('scan-status')
  const runBtn  = document.getElementById('scan-run-btn')
  const clearBtn = document.getElementById('scan-clear-btn')
  if (!block) return

  if (!state.currentClient) {
    block.style.display = 'none'
    return
  }
  block.style.display = 'block'

  const manifest = state.manifest
  if (manifest?.clips?.length) {
    const scannedAt = new Date(manifest.scanned_at).toLocaleDateString()
    const summary   = scanner.summarizeManifest(manifest)
    if (status)   status.textContent  = `✓ ${manifest.clips.length} clips scanned ${scannedAt} — ${summary}`
    if (runBtn)   runBtn.textContent  = '↺ Re-scan'
    if (clearBtn) clearBtn.style.display = 'inline'
  } else {
    if (status)   status.textContent  = 'No scan yet. Run Deep Scan before editing.'
    if (runBtn)   runBtn.textContent  = '✦ Run Deep Scan'
    if (clearBtn) clearBtn.style.display = 'none'
  }
  updateEditButton()
}

function updateEditButton() {
  const btn = document.getElementById('run-edit-btn')
  if (!btn) return
  const hasManifest = !!state.manifest?.clips?.length
  const hasScript   = !!state.selectedScript
  btn.disabled = !hasManifest || !hasScript
  btn.title    = !hasManifest ? 'Run Deep Scan first'
               : !hasScript   ? 'Select a script first'
               : ''
}

async function handleDeepScan() {
  if (!state.currentProject) { toast('No project open — select a client first', 'error'); return }
  if (!state.currentClient)  { toast('Select a client first', 'error'); return }

  const scanBtn    = document.getElementById('scan-run-btn')
  const scanStatus = document.getElementById('scan-status')

  if (scanBtn) scanBtn.disabled = true
  setRunning(true)
  setStatus('running', 'Deep Scan running…')

  try {
    state.manifest = await scanner.runDeepScan(
      state.currentProject,
      state.currentClient,
      (message, current, total) => {
        if (scanStatus) scanStatus.textContent = `${message} (${current}/${total})`
        setStatus('running', message)
      }
    )
    toast(`Deep Scan complete — ${state.manifest.clips.length} clips analyzed`, 'success')
    setStatus('ready', 'Deep Scan complete')
  } catch (err) {
    toast(err.message || 'Deep Scan failed', 'error')
    setStatus('idle', 'Scan error')
  } finally {
    setRunning(false)
    if (scanBtn) scanBtn.disabled = false
    updateScanUI()
  }
}

function handleClearScan() {
  if (!state.currentClient) return
  storage.clearManifest(state.currentClient.id)
  state.manifest = null
  updateScanUI()
  toast('Scan cleared', 'success')
}

// ─── Autonomous Edit ──────────────────────────────────
async function handleRunEdit() {
  if (!state.currentProject) { toast('No project open', 'error'); return }
  if (!state.selectedScript) { toast('Select a script first', 'error'); return }
  if (!state.manifest?.clips?.length) { toast('Run Deep Scan first', 'error'); return }

  const script = state.selectedScript
  const seqSettings = storage.getSeqSettings()
  const seqName = premiere.buildSequenceName(
    state.currentClient.name,
    script.title || script.script_content?.hook || 'Untitled'
  )

  setRunning(true)
  setStatus('running', 'Creating sequence…')

  let sequence = null
  try {
    const exists = await premiere.sequenceExists(state.currentProject, seqName)
    if (exists) {
      sequence = await premiere.getSequenceByName(state.currentProject, seqName)
    } else {
      sequence = await premiere.createSequence(state.currentProject, seqName, seqSettings)
    }
  } catch (err) {
    toast('Could not create sequence: ' + err.message, 'error')
    setRunning(false)
    setStatus('idle', 'Error')
    return
  }

  const editStatusEl = document.getElementById('edit-progress-label')

  try {
    const result = await editor.runEdit(
      state.currentProject,
      sequence,
      script,
      state.manifest,
      seqSettings,
      (message, step, steps) => {
        setStatus('running', message)
        if (editStatusEl) editStatusEl.textContent = `${message} (${step}/${steps})`
      }
    )

    const msg = `E.V.E. edit complete — ${result.beats_placed} clips placed${result.total_duration ? ` · ${Math.round(result.total_duration)}s` : ''}`
    toast(msg, 'success')
    setStatus('ready', 'Edit complete')
    if (editStatusEl) editStatusEl.textContent = result.summary || msg

  } catch (err) {
    toast(err.message || 'Edit failed', 'error')
    setStatus('idle', 'Edit error')
  } finally {
    setRunning(false)
  }
}

// ─── Workspace ────────────────────────────────────────
async function handleSetWorkspace() {
  setRunning(true)
  try {
    const path = await premiere.pickWorkspaceFolder()
    if (!path) return
    state.workspace = path
    storage.saveWorkspace(path)
    document.getElementById('workspace-banner').style.display = 'none'
    toast('Workspace set', 'success')
    if (state.currentClient) {
      await openClientProject(state.currentClient.id, state.currentClient.name)
    }
  } catch { toast('Could not set workspace', 'error') }
  finally { setRunning(false) }
}

async function openClientProject(clientId, clientName) {
  if (!state.workspace) return
  setStatus('running', 'Opening project…')
  setRunning(true)
  const projectPath = premiere.buildProjectPath(state.workspace, clientName)
  storage.saveProjectPath(clientId, projectPath)
  try {
    state.currentProject = await premiere.openOrCreateProject(projectPath, clientName)
    setStatus('ready', `${clientName} project open`)
    toast(`${clientName} project ready`, 'success')
  } catch {
    toast('Could not open Premiere project', 'error')
    setStatus('idle', 'Project error')
  } finally { setRunning(false) }
}

// ─── Sequence-only (manual workflow) ─────────────────
async function handleCreateSequence() {
  if (!state.currentProject) { toast('No project open — select a client first', 'error'); return }
  if (!state.selectedScript) { toast('Select a script to create a sequence for', 'error'); return }

  const seqName = premiere.buildSequenceName(
    state.currentClient.name,
    state.selectedScript.title || state.selectedScript.script_content?.hook || 'Untitled'
  )
  setRunning(true)
  setStatus('running', 'Creating sequence…')
  try {
    const exists = await premiere.sequenceExists(state.currentProject, seqName)
    if (exists) { toast('Sequence already exists for this script', 'error'); return }
    const seqSettings = storage.getSeqSettings()
    await premiere.createSequence(state.currentProject, seqName, seqSettings)
    const settingsLabel = seqSettings ? `${seqSettings.resolution} · ${seqSettings.fps}fps · ${seqSettings.codec}` : ''
    toast(`Sequence created: ${seqName}${settingsLabel ? ' — ' + settingsLabel : ''}`, 'success')
    setStatus('ready', 'Sequence ready')
  } catch { toast('Failed to create sequence', 'error'); setStatus('idle', 'Error') }
  finally { setRunning(false) }
}

async function handleImportFootage() {
  if (!state.currentProject) { toast('No project open — select a client first', 'error'); return }
  const lastFolder = storage.getLastFolder(state.currentClient?.id)
  setRunning(true)
  setStatus('running', 'Selecting footage…')
  try {
    const { imported, folderPath } = await premiere.importFootage(state.currentProject, lastFolder)
    if (imported === 0) { setStatus('ready', 'Ready'); return }
    if (folderPath && state.currentClient) storage.saveLastFolder(state.currentClient.id, folderPath)
    toast(`${imported} file${imported !== 1 ? 's' : ''} imported`, 'success')
    setStatus('ready', 'Footage imported')
    // If no manifest yet, nudge user to scan
    if (!state.manifest?.clips?.length) {
      setTimeout(() => toast('Footage imported — run Deep Scan to enable auto editing', 'info'), 1500)
    }
  } catch { toast('Import failed', 'error'); setStatus('idle', 'Error') }
  finally { setRunning(false) }
}

function showOnboardingGuide() {
  onboardStep = 0
  renderOnboardStep()
  showView('onboarding')
}

// ─── Expose to HTML onclick handlers ─────────────────
window.app = {
  init, nextOnboardStep, prevOnboardStep, finishOnboarding,
  switchStorageTab, handleLogin, handleSignOut,
  handleClientChange, handleSetWorkspace,
  handleCreateSequence, handleImportFootage, showOnboardingGuide,
  toggleSeqSettings, saveSeqSettings, handleToggleFilmed,
  openScriptFocus, closeScriptFocus, handleRunWithScript,
  handleDeepScan, handleClearScan, handleRunEdit,
}

// Auto-start
init().catch(err => {
  document.body.innerHTML = `<div style="padding:20px;color:#f87171;font-family:monospace;font-size:11px;white-space:pre-wrap;">${err?.stack || err}</div>`
})
