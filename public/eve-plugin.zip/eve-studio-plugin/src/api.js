/**
 * api.js — EVE Studio API + Supabase auth
 */

const SUPABASE_URL  = 'https://ricblyvofvdhffgxufjq.supabase.co'
const SUPABASE_ANON = 'sb_publishable_7sh69khOX3rbaZ6iC2jG_A_6hDkU1EN'

let _session = null

function authHeaders() {
  return {
    'Content-Type': 'application/json',
    'apikey': SUPABASE_ANON,
    'Authorization': `Bearer ${_session?.access_token || SUPABASE_ANON}`,
  }
}

window.api = {
  setSession(s) { _session = s },
  getSession()  { return _session },

  async signIn(email, password) {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON },
      body: JSON.stringify({ email, password }),
    })
    const data = await res.json()
    if (!res.ok) throw new Error(data.error_description || data.msg || 'Sign in failed')
    return data
  },

  async refreshSession(refreshToken) {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON },
      body: JSON.stringify({ refresh_token: refreshToken }),
    })
    const data = await res.json()
    if (!res.ok) throw new Error('Session expired')
    return data
  },

  async getUser() {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, { headers: authHeaders() })
    if (!res.ok) throw new Error('Not authenticated')
    return res.json()
  },

  async getProfile(userId) {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}&select=*`,
      { headers: authHeaders() }
    )
    const rows = await res.json()
    return rows[0] || null
  },

  async getThemes() {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/themes?select=*&order=client_name.asc`,
      { headers: authHeaders() }
    )
    if (!res.ok) throw new Error('Failed to load clients')
    return res.json()
  },

  async getScriptsForTheme(themeId) {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/scripts?theme_id=eq.${themeId}&order=created_at.desc&select=*`,
      { headers: authHeaders() }
    )
    if (!res.ok) throw new Error('Failed to load scripts')
    return res.json()
  },
}
