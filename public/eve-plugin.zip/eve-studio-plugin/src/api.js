/**
 * api.js — EVE Studio API + Supabase auth
 */

const EVE_API        = 'https://theevestudio.io'
const SUPABASE_URL   = 'https://ricblyvofvdhffgxufjq.supabase.co'
const SUPABASE_ANON  = 'sb_publishable_7sh69khOX3rbaZ6iC2jG_A_6hDkU1EN'
const CURRENT_VERSION = '1.0.0-beta.1' // local build version

let _session = null

function authHeaders() {
  return {
    'Content-Type': 'application/json',
    'apikey': SUPABASE_ANON,
    'Authorization': `Bearer ${_session?.access_token || SUPABASE_ANON}`,
  }
}

function eveHeaders() {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${_session?.access_token || ''}`,
  }
}

window.api = {
  setSession(s) { _session = s },
  getSession()  { return _session },
  getCurrentVersion() { return CURRENT_VERSION },

  // ── Auth ─────────────────────────────────────────────────────────
  async signIn(email, password) {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON },
      body: JSON.stringify({ email, password }),
    })
    const data = await res.json()
    if (!res.ok) throw new Error(data.error_description || data.msg || 'Sign in failed')
    return data
  },

  async refreshSession(refreshToken) {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON },
      body: JSON.stringify({ refresh_token: refreshToken }),
    })
    const data = await res.json()
    if (!res.ok) throw new Error('Session expired')
    return data
  },

  async getUser() {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, { headers: authHeaders() })
    if (!res.ok) throw new Error('Not authenticated')
    return res.json()
  },

  async getProfile(userId) {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}&select=*`,
      { headers: authHeaders() }
    )
    const rows = await res.json()
    return rows[0] || null
  },

  // ── Studio data ──────────────────────────────────────────────────
  async getThemes() {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/themes?select=*&order=client_name.asc`,
      { headers: authHeaders() }
    )
    if (!res.ok) throw new Error('Failed to load clients')
    return res.json()
  },

  async getScriptsForTheme(themeId) {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/scripts?theme_id=eq.${themeId}&order=created_at.desc&select=*`,
      { headers: authHeaders() }
    )
    if (!res.ok) throw new Error('Failed to load scripts')
    return res.json()
  },

  async setFilmed(scriptId, filmed) {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/scripts?id=eq.${scriptId}`,
      {
        method: 'PATCH',
        headers: { ...authHeaders(), 'Prefer': 'return=minimal' },
        body: JSON.stringify({ filmed }),
      }
    )
    if (!res.ok) throw new Error('Failed to update filmed status')
  },

  // ── Version check ────────────────────────────────────────────────
  async checkVersion() {
    try {
      const res = await fetch(`${EVE_API}/api/plugin/version?channel=beta`)
      if (!res.ok) return null
      return res.json() // { version, channel }
    } catch { return null }
  },

  // ── Deep Scan — clip analysis ────────────────────────────────────
  async analyzeClip({ name, path, duration, frames }) {
    const res = await fetch(`${EVE_API}/api/plugin/analyze-clip`, {
      method: 'POST',
      headers: eveHeaders(),
      body: JSON.stringify({ name, path, duration, frames }),
    })
    if (!res.ok) throw new Error('Clip analysis failed')
    return res.json()
  },

  // ── Edit pipeline — build edit plan ─────────────────────────────
  async buildEditPlan({ script, manifest, sequence_settings }) {
    const res = await fetch(`${EVE_API}/api/plugin/build-edit-plan`, {
      method: 'POST',
      headers: eveHeaders(),
      body: JSON.stringify({ script, manifest, sequence_settings }),
    })
    if (!res.ok) throw new Error('Failed to build edit plan')
    return res.json()
  },
}
