/**
 * premiere.js — Premiere Pro UXP API interactions
 *
 * All timeline operations use try/catch — the UXP API evolves with Premiere
 * versions. Functions degrade gracefully with console warnings when an API
 * is not available in the current Premiere build.
 */

// Premiere ticks per second (internal time unit)
const TICKS_PER_SEC = 254016000000

// Premiere color label indices (0 = None, then by label slot)
const COLOR_LABEL = {
  none:   0,
  violet: 4,   // Lavender
  teal:   8,   // Cerulean
  blue:   1,   // Blue
  green:  2,   // Green
  yellow: 3,   // Yellow
  orange: 5,   // Rose
  red:    7,   // Red
}

window.premiere = {

  // ── Project ──────────────────────────────────────────────────────
  async openOrCreateProject(projectPath) {
    const ppro = require('premierepro')
    try {
      const active = await ppro.Project.getActiveProject()
      if (active && active.path === projectPath) return active
    } catch { /* no active project */ }
    try {
      return await ppro.Project.openDocument(projectPath)
    } catch {
      return await ppro.Project.createProject(projectPath)
    }
  },

  // ── Sequences ────────────────────────────────────────────────────
  async createSequence(project, sequenceName, settings) {
    const seq = await project.createSequence(sequenceName)
    if (settings && seq) {
      try {
        const [w, h] = settings.resolution.split('x').map(Number)
        if (w && h) {
          seq.frameSizeHorizontal = w
          seq.frameSizeVertical   = h
        }
      } catch { /* read-only in this PP version */ }
    }
    return seq
  },

  async sequenceExists(project, name) {
    const sequences = await project.getSequenceList()
    return sequences.some(s => s.name === name)
  },

  async getSequenceByName(project, name) {
    const sequences = await project.getSequenceList()
    return sequences.find(s => s.name === name) || null
  },

  // ── Footage ──────────────────────────────────────────────────────
  async importFootage(project, lastFolderPath) {
    const { localFileSystem } = require('uxp').storage
    let initialDomain = null
    if (lastFolderPath) {
      try {
        initialDomain = await localFileSystem.getEntryWithUrl('file://' + encodeURI(lastFolderPath))
      } catch { /* ignore */ }
    }
    const files = await localFileSystem.getFileForOpening({
      allowMultiple: true,
      initialDomain,
      types: ['mp4', 'mov', 'mxf', 'avi', 'mkv', 'r3d', 'braw', 'dng', 'arw'],
    })
    if (!files || (Array.isArray(files) && files.length === 0)) {
      return { imported: 0, folderPath: null }
    }
    const fileArray = Array.isArray(files) ? files : [files]
    const folderPath = fileArray[0].nativePath.substring(0, fileArray[0].nativePath.lastIndexOf('/'))
    await project.importFiles(fileArray.map(f => f.nativePath), false, project.rootItem, false)
    return { imported: fileArray.length, folderPath }
  },

  async pickWorkspaceFolder() {
    const { localFileSystem } = require('uxp').storage
    const folder = await localFileSystem.getFolder()
    return folder ? folder.nativePath : null
  },

  buildProjectPath(workspacePath, clientName) {
    const safeName = clientName.replace(/[^a-zA-Z0-9 _-]/g, '').trim().replace(/\s+/g, '_')
    return `${workspacePath}/${safeName}.prproj`
  },

  buildSequenceName(clientName, scriptTitle) {
    const title = scriptTitle.replace(/[^a-zA-Z0-9 \-'.,!?]/g, '').trim()
    return `${clientName} — ${title}`
  },

  // ── Bin / Clip access ─────────────────────────────────────────────
  // Recursively walk the project bin and return all video clips
  async getAllVideoClips(project) {
    const clips = []
    const VIDEO_EXTS = /\.(mp4|mov|mxf|avi|mkv|r3d|braw|dng|arw)$/i

    async function traverse(item) {
      try {
        // A clip item has a footage file path
        const path = typeof item.getFootageFilePath === 'function'
          ? item.getFootageFilePath()
          : (item.mediaPath || '')

        if (path && VIDEO_EXTS.test(path)) {
          let duration = 0
          try {
            const inPt  = item.getInPoint?.()  || { seconds: 0 }
            const outPt = item.getOutPoint?.() || { seconds: 0 }
            duration = (outPt.seconds || 0) - (inPt.seconds || 0)
            if (duration <= 0) {
              // Some UXP versions return ticks not seconds
              duration = ((outPt.ticks || 0) - (inPt.ticks || 0)) / TICKS_PER_SEC
            }
          } catch {}

          clips.push({ item, name: item.name, path, duration })
        }

        // Recurse into bins/folders
        const children = item.getItems ? await item.getItems() : null
        if (children) {
          for (const child of children) await traverse(child)
        }
      } catch (err) {
        console.warn('[premiere.getAllVideoClips] traverse error:', err)
      }
    }

    await traverse(project.rootItem)
    return clips
  },

  // Extract thumbnail frames from a clip as base64 JPEG strings
  async getClipFrames(clip, count = 4) {
    const frames = []
    // Try Premiere's smart thumbnail API
    try {
      const thumb = await clip.item.getSmartThumbnail?.(320, 180)
      if (thumb) {
        const canvas = document.createElement('canvas')
        canvas.width = 320; canvas.height = 180
        const ctx = canvas.getContext('2d')
        ctx.drawImage(thumb, 0, 0)
        const b64 = canvas.toDataURL('image/jpeg', 0.7).split(',')[1]
        if (b64) for (let i = 0; i < count; i++) frames.push(b64) // same frame repeated — better than nothing
      }
    } catch { /* thumbnail API not available in this PP version */ }
    return frames
  },

  // Apply a color label to a bin clip
  async setClipLabel(clip, colorLabel) {
    const idx = COLOR_LABEL[colorLabel] ?? 0
    try {
      if (clip.item?.setColorLabel) await clip.item.setColorLabel(idx)
    } catch { /* non-fatal */ }
  },

  // Find a bin clip by its file path
  async findClipByPath(project, filePath) {
    const clips = await this.getAllVideoClips(project)
    return clips.find(c => c.path === filePath) || null
  },

  // Organize bin into folders by category
  async organizeBins(project, clips) {
    const categories = [...new Set(clips.map(c => c.category).filter(Boolean))]
    for (const cat of categories) {
      try {
        const binName = cat.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())
        // Create bin if not exists
        let bin = null
        try {
          const items = await project.rootItem.getItems()
          bin = items.find(i => i.name === binName && i.type === 2 /* bin */)
        } catch {}
        if (!bin) bin = await project.rootItem.createBin?.(binName)
        if (!bin) continue
        // Move clips into the bin
        for (const c of clips) {
          if (c.category === cat) {
            try { await c.item?.moveBin?.(bin) } catch {}
          }
        }
      } catch { /* non-fatal */ }
    }
  },

  // ── Timeline editing ──────────────────────────────────────────────
  /**
   * Insert a projectItem clip into a sequence at a specific timeline position
   * with in/out points already applied.
   *
   * Tries three different UXP API approaches in order of preference.
   */
  async insertClipIntoSequence(sequence, projectItem, timelinePos, inPoint, outPoint) {
    // Set in/out on the source clip first
    try {
      if (projectItem.setInPoint) {
        projectItem.setInPoint(inPoint * TICKS_PER_SEC)
      }
      if (projectItem.setOutPoint) {
        projectItem.setOutPoint(outPoint * TICKS_PER_SEC)
      }
    } catch { /* some items are read-only — skip */ }

    const positionTicks = timelinePos * TICKS_PER_SEC

    // Method A: insertClipsIntoSequence (Premiere 2024+)
    if (sequence.insertClipsIntoSequence) {
      try {
        await sequence.insertClipsIntoSequence([{
          clipProjectItem: projectItem,
          startTime:       { ticks: positionTicks },
          inPoint:         { ticks: inPoint  * TICKS_PER_SEC },
          outPoint:        { ticks: outPoint * TICKS_PER_SEC },
        }], 0)
        return
      } catch (e) { console.warn('Method A failed:', e) }
    }

    // Method B: insertClip (legacy UXP)
    if (sequence.insertClip) {
      try {
        await sequence.insertClip(projectItem, positionTicks, 0, 0)
        return
      } catch (e) { console.warn('Method B failed:', e) }
    }

    // Method C: appendClipToEnd (fallback — ignores position but places clip)
    if (sequence.appendClipToEnd) {
      try {
        await sequence.appendClipToEnd(projectItem, 0, 0)
        return
      } catch (e) { console.warn('Method C failed:', e) }
    }

    throw new Error('No timeline insertion method available in this Premiere version')
  },

  // Mute a clip at a given timeline position
  async muteClipAudio(sequence, timelinePosition) {
    try {
      const tracks = await sequence.getAudioTrackList?.()
      if (!tracks) return
      for (const track of tracks) {
        const clips = await track.getClips?.()
        if (!clips) continue
        for (const clip of clips) {
          const start = clip.start?.seconds || clip.start?.ticks / TICKS_PER_SEC || 0
          if (Math.abs(start - timelinePosition) < 0.5) {
            await clip.setMute?.(true)
          }
        }
      }
    } catch { /* non-fatal */ }
  },

  // Trim silence at the head and tail of all clips in the sequence
  // (Placeholder — full implementation requires audio level analysis)
  async cleanSequenceAudio(_sequence) {
    // TODO: iterate sequence clips, check audio waveform for silence at edges,
    // trim 2-4 frames of dead air from head and tail of each clip.
    // For now this is a no-op that future builds will fill in.
    return true
  },
}
