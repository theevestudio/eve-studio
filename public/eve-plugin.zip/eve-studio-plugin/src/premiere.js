/**
 * premiere.js — Premiere Pro UXP API interactions
 */

window.premiere = {
  async openOrCreateProject(projectPath) {
    const ppro = require('premierepro')
    try {
      const active = await ppro.Project.getActiveProject()
      if (active && active.path === projectPath) return active
    } catch { /* no active project */ }
    try {
      return await ppro.Project.openDocument(projectPath)
    } catch {
      return await ppro.Project.createProject(projectPath)
    }
  },

  async createSequence(project, sequenceName, settings) {
    const seq = await project.createSequence(sequenceName)
    if (settings && seq) {
      try {
        const [w, h] = settings.resolution.split('x').map(Number)
        if (w && h) {
          seq.frameSizeHorizontal = w
          seq.frameSizeVertical   = h
        }
      } catch { /* read-only in this PP version — user sets manually */ }
    }
    return seq
  },

  async sequenceExists(project, name) {
    const sequences = await project.getSequenceList()
    return sequences.some(s => s.name === name)
  },

  async importFootage(project, lastFolderPath) {
    const { localFileSystem } = require('uxp').storage
    let initialDomain = null
    if (lastFolderPath) {
      try {
        initialDomain = await localFileSystem.getEntryWithUrl('file://' + encodeURI(lastFolderPath))
      } catch { /* ignore */ }
    }

    const files = await localFileSystem.getFileForOpening({
      allowMultiple: true,
      initialDomain,
      types: ['mp4', 'mov', 'mxf', 'avi', 'mkv', 'r3d', 'braw', 'dng', 'arw']
    })

    if (!files || (Array.isArray(files) && files.length === 0)) return { imported: 0, folderPath: null }

    const fileArray = Array.isArray(files) ? files : [files]
    const folderPath = fileArray[0].nativePath.substring(0, fileArray[0].nativePath.lastIndexOf('/'))
    const filePaths = fileArray.map(f => f.nativePath)

    await project.importFiles(filePaths, false, project.rootItem, false)
    return { imported: filePaths.length, folderPath }
  },

  async pickWorkspaceFolder() {
    const { localFileSystem } = require('uxp').storage
    const folder = await localFileSystem.getFolder()
    return folder ? folder.nativePath : null
  },

  buildProjectPath(workspacePath, clientName) {
    const safeName = clientName.replace(/[^a-zA-Z0-9 _-]/g, '').trim().replace(/\s+/g, '_')
    return `${workspacePath}/${safeName}.prproj`
  },

  buildSequenceName(clientName, scriptTitle) {
    const title = scriptTitle.replace(/[^a-zA-Z0-9 \-'.,!?]/g, '').trim()
    return `${clientName} — ${title}`
  },
}
