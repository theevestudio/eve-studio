/**
 * scanner.js — Deep Scan: walk the Premiere project bin, classify every clip,
 * build a footage manifest, and apply color labels.
 *
 * Call: await scanner.runDeepScan(project, client, onProgress)
 * Returns: manifest object (also saved to storage)
 */

const MANIFEST_VERSION = 1

window.scanner = {

  async runDeepScan(project, client, onProgress) {
    onProgress('Scanning project bin…', 0, 1)

    // ── 1. Collect all video clips from the Premiere bin ─────────────
    let clips = []
    try {
      clips = await premiere.getAllVideoClips(project)
    } catch (err) {
      throw new Error('Could not read project bin: ' + err.message)
    }

    if (clips.length === 0) {
      throw new Error('No video files found in this project. Import footage first.')
    }

    const manifest = {
      version:    MANIFEST_VERSION,
      scanned_at: Date.now(),
      client_id:  client.id,
      clips:      [],
    }

    // ── 2. Analyze each clip ─────────────────────────────────────────
    for (let i = 0; i < clips.length; i++) {
      const clip = clips[i]
      onProgress(`Analyzing ${clip.name}`, i, clips.length)

      let frames = []
      try {
        frames = await premiere.getClipFrames(clip, 4)
      } catch {
        // Frame extraction not available — metadata-only analysis
      }

      let result = {
        category:      'unknown',
        subcategory:   'other',
        description:   clip.name,
        tags:          [],
        energy_level:  'medium',
        suggested_label: clip.name,
        color_label:   'none',
      }

      try {
        result = await api.analyzeClip({
          name:     clip.name,
          path:     clip.path,
          duration: clip.duration,
          frames,
        })
      } catch (err) {
        console.warn('[scanner] analyzeClip failed for', clip.name, err)
      }

      // Apply color label in Premiere bin
      try {
        await premiere.setClipLabel(clip, result.color_label)
      } catch { /* non-fatal */ }

      manifest.clips.push({
        name:          clip.name,
        path:          clip.path,
        duration:      clip.duration,
        category:      result.category,
        subcategory:   result.subcategory,
        description:   result.description,
        tags:          result.tags || [],
        energy_level:  result.energy_level,
        color_label:   result.color_label,
        suggested_label: result.suggested_label,
      })
    }

    // ── 3. Rename bins in Premiere by category ───────────────────────
    try {
      await premiere.organizeBins(project, manifest.clips)
    } catch { /* non-fatal */ }

    // ── 4. Save manifest ──────────────────────────────────────────────
    storage.saveManifest(client.id, manifest)

    onProgress('Deep Scan complete', clips.length, clips.length)
    return manifest
  },

  // Returns a summary string for display
  summarizeManifest(manifest) {
    if (!manifest?.clips?.length) return 'No clips scanned'
    const counts = {}
    for (const c of manifest.clips) {
      counts[c.category] = (counts[c.category] || 0) + 1
    }
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .map(([cat, n]) => `${n} ${cat.replace('_', ' ')}`)
      .join(' · ')
  },
}
