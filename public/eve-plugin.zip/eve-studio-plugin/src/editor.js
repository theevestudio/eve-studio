/**
 * editor.js — Autonomous Edit: fetch an edit plan from the server,
 * then execute it: insert clips, set in/out points, clean audio.
 *
 * Call: await editor.runEdit(project, sequence, script, manifest, settings, onProgress)
 * Returns: { beats_placed, total_beats, summary }
 */

window.editor = {

  async runEdit(project, sequence, script, manifest, seqSettings, onProgress) {

    // ── 1. Build edit plan via server ────────────────────────────────
    onProgress('E.V.E. is reading your script…', 0, 5)

    let plan
    try {
      plan = await api.buildEditPlan({
        script:            script.script_content,
        manifest,
        sequence_settings: seqSettings,
      })
    } catch (err) {
      throw new Error('Could not build edit plan: ' + err.message)
    }

    if (!plan?.edit_plan?.length) {
      throw new Error('E.V.E. could not generate an edit plan. Check that your manifest has footage.')
    }

    // ── 2. Resolve projectItems by file path ─────────────────────────
    onProgress('Locating clips in project…', 1, 5)

    const allClips = await premiere.getAllVideoClips(project)
    const clipsByPath = {}
    for (const c of allClips) clipsByPath[c.path] = c

    const resolved = []
    for (const beat of plan.edit_plan) {
      const clip = clipsByPath[beat.clip_path]
      if (clip) {
        resolved.push({ ...beat, clip })
      } else {
        console.warn('[editor] Could not find clip in project:', beat.clip_path)
      }
    }

    if (resolved.length === 0) {
      throw new Error('None of the planned clips were found in the Premiere project. Make sure footage is imported.')
    }

    // ── 3. Insert clips into sequence ────────────────────────────────
    onProgress(`Cutting ${resolved.length} clips into timeline…`, 2, 5)

    let successCount = 0
    for (const beat of resolved) {
      try {
        await premiere.insertClipIntoSequence(
          sequence,
          beat.clip.item,
          beat.timeline_position,
          beat.in_point,
          beat.out_point,
        )
        // Apply EVE color label on timeline clip
        await premiere.setClipLabel(beat.clip, 'violet')
        successCount++
      } catch (err) {
        console.error('[editor] Failed to insert', beat.clip_name, err)
      }
    }

    // ── 4. Handle audio per beat ─────────────────────────────────────
    onProgress('Cleaning audio…', 3, 5)
    try {
      for (const beat of resolved) {
        if (beat.audio_action === 'mute') {
          await premiere.muteClipAudio(sequence, beat.timeline_position)
        }
        // "duck" is handled by Premiere's auto-ducking — we set a flag
      }
    } catch { /* non-fatal */ }

    // ── 5. Clean silence at heads/tails ─────────────────────────────
    try {
      await premiere.cleanSequenceAudio(sequence)
    } catch { /* non-fatal */ }

    onProgress('Done', 5, 5)

    return {
      beats_placed: successCount,
      total_beats:  plan.edit_plan.length,
      summary:      plan.summary || `${successCount} clips placed`,
      total_duration: plan.total_duration,
    }
  },
}
