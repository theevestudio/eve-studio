# E.V.E. — Premiere Pro Plugin

Adobe UXP panel plugin for Premiere Pro. Requires an active EVE Monthly subscription.

## Install (Developer Mode)

1. Download and install **Adobe UXP Developer Tools** from the Creative Cloud desktop app
2. Open UXP Developer Tools
3. Click **Add Plugin** → select this folder (`eve-studio-plugin/`)
4. Click **Load** — the E.V.E. panel will appear in Premiere Pro under Window → Extensions → E.V.E.

## Requirements

- Adobe Premiere Pro 25.0+
- Active EVE Monthly subscription at theevestudio.io
- Internet connection

## Distribution (after beta)

Submit to Adobe Exchange marketplace for one-click install by subscribers.
